const mongoose = require("mongoose");

const connectDB = () => {
  console.log("process.env.DATABASE_URL ==> ", process.env.DATABASE_URL)
  mongoose.connect(process.env.DATABASE_URL)
    .then(() => {
      console.log("Connected to MongoDB");
    })
    .catch((error) => {
      console.error("Error connecting to MongoDB: ", error);
    });
};

module.exports = connectDB;
